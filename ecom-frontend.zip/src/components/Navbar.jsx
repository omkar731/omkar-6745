import React from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <nav style={{ padding: '10px', background: '#333', color: 'white' }}>
      <h3 style={{ display: 'inline', marginRight: '20px' }}>E-Commerce</h3>
      <button onClick={handleLogout}>Logout</button>
    </nav>
  );
};

export default Navbar;